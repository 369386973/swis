import { Page404 } from '@/components/Page404'

export default Page404
