import { ErrorPage } from '@/components/ErrorPage'

export default ErrorPage
